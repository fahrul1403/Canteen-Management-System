<footer>
    <div class="footer-content">
        <h3>Kowandi Gathering Food</h3>
        <p>"Don't forget to stop before go to campus"</p>
        <ul class="medsos">
            <li><a class="sosmed" id="m-1" href="#"><i class="fab fa-instagram"></i></a></li>
            <li><a class="sosmed" id="m-2" href="#"><i class="fab fa-whatsapp"></i></a></li>
        </ul>
    </div>
    <div class="footer-bottom">
        <p>Copyright &copy;2023 <a href="../developer/kintondev.php" target="_blank"
                class="dev">KowandiGatheringFoodDev</a></p>
    </div>
</footer>